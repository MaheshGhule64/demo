<!DOCTYPE html>
<html lang="zxx" class="no-js">
<head>
    <!-- Mobile Specific Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/fav.png">
    <!-- Author Meta -->
    <meta name="author" content="colorlib">
    <!-- Meta Description -->
    <meta name="description" content="">
    <!-- Meta Keyword -->
    <meta name="keywords" content="">
    <!-- meta character set -->
    <meta charset="UTF-8">
    <!-- Site Title -->
    <title>TEMPLATE-4</title>

    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
        <!--
        CSS
        ============================================= -->
        <link rel="stylesheet" href="css/linearicons.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link href="css/all.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/bootstrap.css">
        <link href="vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
        <link rel="stylesheet" href="css/magnific-popup.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link  rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link href="swiper/swiper-bundle.min.css" rel="stylesheet">

    </head>
    <body>
        <!-- start banner Area -->
        <section class="banner-area" id="home">
            <!-- Start Header Area -->
      <!--      <header class="default-header">
                <nav class="navbar navbar-expand-lg  navbar-dark">
                    <div class="container">
                          <a class="navbar-brand" href="index.html">
                              <img src="img/logo.png" alt="">
                          </a>
                          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="text-white lnr lnr-menu"></span>
                          </button>

                          <div class="collapse navbar-collapse justify-content-end align-items-center" id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                <li><a href="index.html">Home</a></li>
									<li><a href="about.html">About</a></li>									
									<li><a href="gallery.html">Gallery</a></li>
									<li><a href="Reservation.html">Table Booking</a></li>
									<li><a href="contact.html">Contact</a></li>  -->
                                <!-- Dropdown -->
                         <!--       <li class="dropdown">
                                  <a class="dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                    Menu
                                  </a>
                                  <div class="dropdown-menu">
                                    <a class="dropdown-item" href="index.html">Lunch Menu</a>
                                    <a class="dropdown-item" href="index.html">Main Menu</a>
                                  </div>
                                </li>
                            </ul>
                          </div>						
                    </div>
                </nav>
            </header>  -->
            <!-- End Header Area -->				
        </section>

       
        <!-- Page Header Start -->
        <div class="page-header mb-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>GALLERY</h2>
                    </div>
                    <div class="col-12">
                        <a href="">Home</a>
                        <a href="">GALLERY</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Header End -->
        

      <!-- gallery_start -->
 <!--<div class="gallery_area">
    <div class="container">
		<div class="title text-center">
			<h1 class="mb-10">GALLERY</h1>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> labore  et dolore magna aliqua.</p>
		</div>
        <div class="row">
        </div>
    </div>
    <div class="single_gallery big_img">
        <a class="popup-image" href="images/order-6.png"></a>
        <img src="images/order-6.png" alt="">
    </div>
</div>-->

    <?php

    echo $show;

    ?>


<!-- gallery end -->
        
        
        <!-- Start project Area -->
        
        <?php

        echo $our_deals;

        ?>
                <!-- order_area_end -->


<!-- ORDER-SECTION STARTS HERE -->
<section class="oder5-secrion">
<div class="container">
    
    <div class="title text-center">
        <h1 class="mb-10">ORDER IN THREE STEPS </h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> labore  et dolore magna aliqua.</p>
    </div>
    <div class="row">
    
        <div class="col-md-4 col-sm-4 order wow slideInUp" data-wow-delay="0.6s">
            <div class="od5-serviceBox">
                <div class="service-content">
                    <div class="service-icon">
                        <img src="images/food11.gif" />
                    </div>
                    <h3 class="title"> 1. ADD ITEMS TO CART</h3>
                    <p class="description">Select your favorite dish from menu and add to cart. </p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-4 order wow slideInUp" data-wow-delay="0.3s">
            <div class="od5-serviceBox">
                <div class="service-content">
                    <div class="service-icon">
                        <img src="images/food12.gif" />
                    </div>
                    <h3 class="title">2. Pay Easily Online</h3>
                    <p class="description">Pay easily online. (Netbanking, credit card, G-pay, etc.)</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-4 order wow slideInUp" data-wow-delay="0.9s">
            <div class="od5-serviceBox">
                <div class="service-content">
                    <div class="service-icon">
                        <img src="images/food13.gif" />
                    </div>
                    <h3 class="title"> 3. Pick Up Easily</h3>
                    <p class="description">Don't forget to rate us or write us your comments. </p>
                </div>
            </div>
        </div>

    </div>
</div>
</section>
<!-- ORDER-SECTION ENDS HERE -->
<!-- gallery_start -->

          
      <!-- testmonial_area_start -->
      <div class="testmonial_area banner-3">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="title text-center">
                        <h1 class="mb-10">WHAT CUSTOMER SAYS! </h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> labore  et dolore magna aliqua.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="testmonial_active owl-carousel">
                        <div class="single_testmonial d-flex">
                            <div class="testmonial_thumb">
                                <img src="img/testmonial/1.png" alt="">
                            </div>
                            <div class="testmonial_author">
                                <h3>Adame Nesane</h3>
                                <span>Chief Customer</span>
                                <p>You're had. Subdue grass Meat us winged years you'll doesn't. fruit two also won one
                                    yielding creepeth third give may never lie alternet food.</p>
                            </div>
                        </div>
                        <div class="single_testmonial d-flex">
                            <div class="testmonial_thumb">
                                <img src="img/testmonial/2.png" alt="">
                            </div>
                            <div class="testmonial_author">
                                <h3>Adam Nahan</h3>
                                <span>Chief Customer</span>
                                <p>You're had. Subdue grass Meat us winged years you'll doesn't. fruit two also won one
                                    yielding creepeth third give may never lie alternet food.</p>
                            </div>
                        </div>
                        <div class="single_testmonial d-flex">
                            <div class="testmonial_thumb">
                                <img src="img/testmonial/1.png" alt="">
                            </div>
                            <div class="testmonial_author">
                                <h3>Adame Nesane</h3>
                                <span>Chief Customer</span>
                                <p>You're had. Subdue grass Meat us winged years you'll doesn't. fruit two also won one
                                    yielding creepeth third give may never lie alternet food.</p>
                            </div>
                        </div>
                        <div class="single_testmonial d-flex">
                            <div class="testmonial_thumb">
                                <img src="img/testmonial/2.png" alt="">
                            </div>
                            <div class="testmonial_author">
                                <h3>Adam Nahan</h3>
                                <span>Chief Customer</span>
                                <p>You're had. Subdue grass Meat us winged years you'll doesn't. fruit two also won one
                                    yielding creepeth third give may never lie alternet food.</p>
                            </div>
                        </div>
                        <div class="single_testmonial d-flex">
                            <div class="testmonial_thumb">
                                <img src="img/testmonial/1.png" alt="">
                            </div>
                            <div class="testmonial_author">
                                <h3>Adame Nesane</h3>
                                <span>Chief Customer</span>
                                <p>You're had. Subdue grass Meat us winged years you'll doesn't. fruit two also won one
                                    yielding creepeth third give may never lie alternet food.</p>
                            </div>
                        </div>
                        <div class="single_testmonial d-flex">
                            <div class="testmonial_thumb">
                                <img src="img/testmonial/2.png" alt="">
                            </div>
                            <div class="testmonial_author">
                                <h3>Adam Nahan</h3>
                                <span>Chief Customer</span>
                                <p>You're had. Subdue grass Meat us winged years you'll doesn't. fruit two also won one
                                    yielding creepeth third give may never lie alternet food.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!--    <footer class="footer">
        <div class="footer_top">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-md-6 col-lg-3 ">
                        <div class="footer_widget">
                            <div class="footer_logo">
                                <a href="#">
                                    <img src="img/barbecue-restaurant-5975755_1280.png" alt="">
                                </a>
                            </div>
                            <h3 class="footer_title">
                               CONTACT US
                            </h3>
                            
                            <p class="ttt">5th flora, 700/D kings road, green <br> lane New York-1782 <br>
                              <i class="bi bi-telephone icon"></i>
                                <a href="#"> </i>+10 367 826 2567</a> <br>
                                <a href="#">contact@carpenter.com</a>
                            </p>
                            
                            
      
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-3 col-lg-4 offset-xl-1">
                        <div class="footer_widget">
                            <h3 class="footer_title">
                                INFORMATION LINKS
                            </h3>
                            <ul>
                                <li><a href="#">Menu</a></li>
                                <li><a href="#">About</a></li>

                                <li><a href="#"> Table Booking</a></li>
                                <li><a href="#"> Contact</a></li>
      
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-3 col-lg-4">
                        <div class="footer_widget">
                          <table class="table table-responsive table-bordered table-hover">
                            <tbody>
                              <tr style="background: brown; color: white; ">
                            
                                <h2 class="opfoo"><i class="bi bi-clock icon"></i>  OPENING HOURS  </h2>
                                <th style="width: 41%;"> Monday-Friday</th>
                                <th style="width: 27%;">10:30 - 21:30</th>
                              </tr>
                              <tr style="background: brown; color: white; ">
                                <th>Saturday</th>
                                <th>12:00 - 21:30</th>
                              </tr>
                              <tr style="background: brown; color: white; ">
                                <th>Sunday</th>
                                <th>Closed</th>
                              </tr>
                              
        
                            </tbody>
                          </table>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right_text">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                          
      Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | @ RestaDigital</a>
      
                        </p>
                    </div>
                </div>
            </div>
        </div>
      </footer>
    
-->
      

        
              <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/vendor/jquery-2.2.4.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <script src="swiper/swiper-bundle.min.js"></script>
        <script src="js/jquery.magnific-popup.min.js"></script>	
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>			
        <script src="js/jquery.sticky.js"></script>
        <script src="js/slick.js"></script>
        <script src="js/jquery.counterup.min.js"></script>
        <script src="js/waypoints.min.js"></script>		
        <script src="js/main.js"></script>	
    </body>
</html>